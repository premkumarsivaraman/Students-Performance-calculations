﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con1 = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=school_project; integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //Button1.Visible = false;
            individial_report_false();
            classwise_report_false();
            groupwise_false();

            lblreg.Visible = false;
            Label9.Visible = false;
            RadioButtonList5.Visible = false;
            GridView2.Visible = false;
            Panel2.Visible = false;
          
        }
    }
    
    protected void RadioButtonList1_SelectedIndexChanged1(object sender, EventArgs e)
    {

        

        if (RadioButtonList1.SelectedValue == "Individual Report")
        {
            classwise_report_false();
            groupwise_false();
            Label1.Visible = true;
            DropDownList1.Visible = true;
            Panel2.Visible = false;
            GridView2.Visible = false;

            SqlDataAdapter ad = new SqlDataAdapter("select distinct class from student_reg ", con1);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataBind();
            DropDownList1.DataTextField="class";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("Select", ""));

        }

        if (RadioButtonList1.SelectedValue == "Classwise Report")
        {
            individial_report_false();
            groupwise_false();
            Label5.Visible = true;
            DropDownList4.Visible = true;
            lblreg.Visible = false;
            GridView2.Visible = false;

            SqlDataAdapter ad = new SqlDataAdapter("select distinct class from student_reg ", con1);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            DropDownList4.DataSource = dt;
            DropDownList4.DataBind();
            DropDownList4.DataTextField = "class";
            DropDownList4.DataBind();
            DropDownList4.Items.Insert(0, new ListItem("Select", ""));
        }
        if (RadioButtonList1.SelectedValue == "Groupwise Report")
        {
            individial_report_false();
            classwise_report_false();
            Label8.Visible = true;
            RadioButtonList4.Visible = true;
        }
       
    }
    protected void RadioButtonList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        ////SqlDataAdapter ad = new SqlDataAdapter("select student_reg.register_number,student_reg.name,student_reg.class,student_reg.section,marks_entry.activity, marks_entry.marks  from student_reg inner join marks_entry on student_reg.register_number = marks_entry.register_number where class='"+DropDownList1.SelectedValue+"' and section = '"+DropDownList2.SelectedValue+"' and register_number = '"+DropDownList3.SelectedValue+"' ",con1);
        //SqlDataAdapter ad = new SqlDataAdapter("select register_number,[group],activity,marks from marks_entry where register_number = '" + DropDownList3.SelectedValue + "' and [group] = '"+RadioButtonList2.SelectedValue+"' ", con1);
        //DataTable dt = new DataTable();
        //ad.Fill(dt);
        RadioButtonList5.ClearSelection();
        Label9.Visible = true;
        RadioButtonList5.Visible = true;
        GridView2.Visible = false;
        Panel2.Visible = true;


        DataTable td = new DataTable();
        td.Columns.Add("S.No");
        td.Columns.Add("Register Number");
        td.Columns.Add("Group");
        SqlDataAdapter ad_activity = new SqlDataAdapter("Select distinct activity from rubrics", con1);
        DataTable dt_activity = new DataTable();
        ad_activity.Fill(dt_activity);
        if (dt_activity.Rows.Count > 0)
        {
            for (int i = 0; i < dt_activity.Rows.Count; i++)
            {
                td.Columns.Add(dt_activity.Rows[i][0].ToString());
            }
        }
        td.Columns.Add("Total");
        td.Columns.Add("Average");
        //DataRow dr = td.NewRow();
        //dr["S.No"] = "1";
        //td.Rows.Add(dr);
        SqlDataAdapter ad_regno = new SqlDataAdapter("Select distinct register_number,[group] from marks_entry where register_number = '" + DropDownList3.SelectedValue + "' and [group]='"+ RadioButtonList2.SelectedValue +"' ", con1);
        DataTable dt_regno = new DataTable();
        ad_regno.Fill(dt_regno);

        SqlDataAdapter ad_group = new SqlDataAdapter("select distinct [group] from marks_entry where [group]='"+RadioButtonList2.SelectedValue+"' ", con1);
        DataTable dt_group = new DataTable();
        ad_group.Fill(dt_group);

        if (dt_regno.Rows.Count > 0)
        {
            lblreg.Visible = false;
            for (int i = 0; i < dt_regno.Rows.Count; i++)
            {
                decimal mark = 0, mark1 = 0;
                //td.Columns.Add(dt_regno.Rows[i][0].ToString());
                DataRow dr = td.NewRow();
                dr["S.No"] = i + 1;
                dr["Register Number"] = dt_regno.Rows[i][0].ToString();
                dr["Group"] = dt_regno.Rows[i][1].ToString();
                if (dt_activity.Rows.Count > 0)
                {

                    for (int j = 0; j < dt_activity.Rows.Count; j++)
                    {
                        //dr[dt_activity.Rows[j][0].ToString()] = "1";
                        SqlDataAdapter ad_mark = new SqlDataAdapter("Select marks from marks_entry where register_number='" + dt_regno.Rows[i][0].ToString() + "' and activity='" + dt_activity.Rows[j][0].ToString() + "'   ", con1);
                        DataTable dt_mark = new DataTable();
                        ad_mark.Fill(dt_mark);
                        if (dt_mark.Rows.Count > 0)
                        {

                            for (int k = 0; k < dt_mark.Rows.Count; k++)
                            {
                                dr[dt_activity.Rows[j][0].ToString()] = dt_mark.Rows[k][0].ToString();
                                mark = Convert.ToDecimal(dt_mark.Rows[k][0].ToString());
                            }

                        }
                        else
                        {
                            dr[dt_activity.Rows[j][0].ToString()] = "0";
                            mark = 0;
                        }

                        mark1 = mark1 + mark;
                    }


                }

                dr["Total"] = mark1.ToString();
                double average = Convert.ToDouble(mark1) / Convert.ToDouble(dt_activity.Rows.Count);
                dr["Average"] = average.ToString("0.00");
                td.Rows.Add(dr);

            }

        }
        else
        {
            lblreg.Visible = true;
            GridView1.Visible = false;
            lblreg.Text = "no data found";
            RadioButtonList5.Visible = false;
            Label9.Visible = false;
           
        }
        
        GridView1.Visible = true;
        GridView1.DataSource = td;
        GridView1.DataBind();

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlDataAdapter ad1 = new SqlDataAdapter("select distinct section from student_reg where class='" + DropDownList1.SelectedValue + "' ", con1);
        DataTable dt1 = new DataTable();
        ad1.Fill(dt1);

        Label2.Visible = true;
        DropDownList2.Visible = true;
        DropDownList2.DataSource = dt1;
        DropDownList2.DataBind();
        DropDownList2.DataTextField = "section";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("Select", ""));

        GridView2.Visible = false;
        RadioButtonList5.ClearSelection();
        RadioButtonList2.ClearSelection();
        DropDownList3.ClearSelection();

    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlDataAdapter ad2 = new SqlDataAdapter("select register_number from student_reg where class ='"+DropDownList1.SelectedValue+"' and section = '"+DropDownList2.SelectedValue+"'", con1);
        DataTable dt2 = new DataTable();
        ad2.Fill(dt2);

        Label3.Visible = true;
        DropDownList3.Visible = true;
        DropDownList3.DataSource = dt2;
        DropDownList3.DataBind();
        DropDownList3.DataTextField = "register_number";
        DropDownList3.DataBind();
        DropDownList3.Items.Insert(0, new ListItem("Select", ""));

        //GridView2.Visible = false;


    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        RadioButtonList2.ClearSelection();
        RadioButtonList5.ClearSelection();
        RadioButtonList5.Visible = false;

        lblreg.Visible = false;

        Label9.Visible = false;
        Label4.Visible = true;
        RadioButtonList2.Visible = true;
        GridView1.Visible = false;
        //GridView2.Visible = false;
        

    }

    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlDataAdapter ad1 = new SqlDataAdapter("select distinct section from student_reg where class='" + DropDownList4.SelectedValue + "' ", con1);
        DataTable dt1 = new DataTable();
        ad1.Fill(dt1);

        Label6.Visible = true;
        DropDownList5.Visible = true;
        DropDownList5.DataSource = dt1;
        DropDownList5.DataTextField = "section";
        DropDownList5.DataBind();
        DropDownList5.Items.Insert(0, new ListItem("Select", ""));

        GridView1.Visible = false;
        RadioButtonList3.ClearSelection();

        Panel2.Visible = false;
        GridView2.Visible = false;


        

       
    }
    protected void DropDownList5_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label7.Visible = true;
        RadioButtonList3.Visible = true;
        GridView1.Visible = false;
        Panel2.Visible = false;
        GridView2.Visible = false;
        RadioButtonList3.ClearSelection();

    }
    protected void RadioButtonList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        RadioButtonList5.ClearSelection();
        GridView2.Visible = false;

        SqlDataAdapter ad2 = new SqlDataAdapter("select student_reg.register_number,student_reg.class,student_reg.section,marks_entry.activity, marks_entry.marks  from student_reg inner join marks_entry on student_reg.register_number = marks_entry.register_number where [group]='" + RadioButtonList4.Text + "' and class = '" + DropDownList4.SelectedValue + "' and section = '" + DropDownList5.SelectedValue + "'", con1);
        DataTable dt2 = new DataTable();
        ad2.Fill(dt2);

        GridView1.Visible = true;
        GridView1.DataSource = dt2;
        GridView1.DataBind();

        RadioButtonList5.Visible = true;
        RadioButtonList5.ClearSelection();

        Panel2.Visible = true;
        //GridView2.Visible = true;


        DataTable td = new DataTable();
        td.Columns.Add("S.No");
        td.Columns.Add("Register Number");
        td.Columns.Add("Group");
        td.Columns.Add("Class");
        td.Columns.Add("Section");
        SqlDataAdapter ad_activity = new SqlDataAdapter("Select distinct activity from rubrics", con1);
        DataTable dt_activity = new DataTable();
        ad_activity.Fill(dt_activity);
        if (dt_activity.Rows.Count > 0)
        {
            for (int i = 0; i < dt_activity.Rows.Count; i++)
            {
                td.Columns.Add(dt_activity.Rows[i][0].ToString());
            }
        }
        td.Columns.Add("Total");
        td.Columns.Add("Average");
        //DataRow dr = td.NewRow();
        //dr["S.No"] = "1";
        //td.Rows.Add(dr);
        

        //SqlDataAdapter ad_group = new SqlDataAdapter("select distinct [group] from marks_entry where [group]='" + RadioButtonList3.SelectedValue + "' ", con1);
        //DataTable dt_group = new DataTable();
        //ad_group.Fill(dt_group);



        SqlDataAdapter ad_regno = new SqlDataAdapter("Select distinct student_reg.register_number,marks_entry.[group],student_reg.class,student_reg.section from student_reg inner join marks_entry on student_reg.register_number = marks_entry.register_number where marks_entry.[group] = '"+ RadioButtonList3.SelectedValue +"' and student_reg.class = '" + DropDownList4.SelectedValue + "' and section = '" + DropDownList5.SelectedValue + "' ", con1);
        DataTable dt_regno = new DataTable();
        ad_regno.Fill(dt_regno);

        if (dt_regno.Rows.Count > 0)
        {

            for (int i = 0; i < dt_regno.Rows.Count; i++)
            {
                decimal mark = 0, mark1 = 0;
                //td.Columns.Add(dt_regno.Rows[i][0].ToString());
                DataRow dr = td.NewRow();
                dr["S.No"] = i + 1;
                dr["Register Number"] = dt_regno.Rows[i][0].ToString();
                dr["Group"] = dt_regno.Rows[i][1].ToString();
                dr["Class"] = dt_regno.Rows[i][2].ToString();
                dr["Section"] = dt_regno.Rows[i][3].ToString();
                if (dt_activity.Rows.Count > 0)
                {

                    for (int j = 0; j < dt_activity.Rows.Count; j++)
                    {
                        //dr[dt_activity.Rows[j][0].ToString()] = "1";
                        
                        
                        //SqlDataAdapter ad_mark = new SqlDataAdapter("select student_reg.register_number,student_reg.class,student_reg.section,marks_entry.register_number,marks_entry.activity,marks_entry.marks from student_reg inner join marks_entry on student_reg.register_number = marks_entry.register_number where class='" + DropDownList4.SelectedValue + "' and section = '" + DropDownList5.SelectedValue + "' and [group] = '" + RadioButtonList3.SelectedValue + "'", con1);


                        SqlDataAdapter ad_mark = new SqlDataAdapter("Select marks from marks_entry where register_number='" + dt_regno.Rows[i][0].ToString() + "' and activity='" + dt_activity.Rows[j][0].ToString() + "'   ", con1);
                        DataTable dt_mark = new DataTable();
                        ad_mark.Fill(dt_mark);
                        if (dt_mark.Rows.Count > 0)
                        {

                            for (int k = 0; k < dt_mark.Rows.Count; k++)
                            {
                                dr[dt_activity.Rows[j][0].ToString()] = dt_mark.Rows[k][0].ToString();
                                mark = Convert.ToDecimal(dt_mark.Rows[k][0].ToString());
                            }

                        }
                        else
                        {
                            dr[dt_activity.Rows[j][0].ToString()] = "0";
                            mark = 0;
                        }

                        mark1 = mark1 + mark;
                    }


                }

                dr["Total"] = mark1.ToString();
                double average = Convert.ToDouble(mark1) / Convert.ToDouble(dt_activity.Rows.Count);
                dr["Average"] = average.ToString("0.00");
                td.Rows.Add(dr);

            }

        }
        GridView1.Visible = true;
        GridView1.DataSource = td;
        GridView1.DataBind();


        

    }
    protected void RadioButtonList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable td = new DataTable();
        td.Columns.Add("S.No");
        td.Columns.Add("Register Number");
        td.Columns.Add("Group");
        td.Columns.Add("Class");
        td.Columns.Add("Section");
        SqlDataAdapter ad_activity = new SqlDataAdapter("Select distinct activity from rubrics", con1);
        DataTable dt_activity = new DataTable();
        ad_activity.Fill(dt_activity);
        if (dt_activity.Rows.Count > 0)
        {
            for (int i = 0; i < dt_activity.Rows.Count; i++)
            {
                td.Columns.Add(dt_activity.Rows[i][0].ToString());
            }
        }
        td.Columns.Add("Total");
        td.Columns.Add("Average");
        //DataRow dr = td.NewRow();
        //dr["S.No"] = "1";
        //td.Rows.Add(dr);


        //SqlDataAdapter ad_group = new SqlDataAdapter("select distinct [group] from marks_entry where [group]='" + RadioButtonList3.SelectedValue + "' ", con1);
        //DataTable dt_group = new DataTable();
        //ad_group.Fill(dt_group);



        SqlDataAdapter ad_regno = new SqlDataAdapter("Select distinct student_reg.register_number,marks_entry.[group],student_reg.class,student_reg.section from student_reg inner join marks_entry on student_reg.register_number = marks_entry.register_number where marks_entry.[group] = '" + RadioButtonList4.SelectedValue + "' ", con1);
        DataTable dt_regno = new DataTable();
        ad_regno.Fill(dt_regno);

        if (dt_regno.Rows.Count > 0)
        {

            for (int i = 0; i < dt_regno.Rows.Count; i++)
            {
                decimal mark = 0, mark1 = 0;
                //td.Columns.Add(dt_regno.Rows[i][0].ToString());
                DataRow dr = td.NewRow();
                dr["S.No"] = i + 1;
                dr["Register Number"] = dt_regno.Rows[i][0].ToString();
                dr["Group"] = dt_regno.Rows[i][1].ToString();
                dr["Class"] = dt_regno.Rows[i][2].ToString();
                dr["Section"] = dt_regno.Rows[i][3].ToString();
                if (dt_activity.Rows.Count > 0)
                {

                    for (int j = 0; j < dt_activity.Rows.Count; j++)
                    {
                        //dr[dt_activity.Rows[j][0].ToString()] = "1";


                        //SqlDataAdapter ad_mark = new SqlDataAdapter("select student_reg.register_number,student_reg.class,student_reg.section,marks_entry.register_number,marks_entry.activity,marks_entry.marks from student_reg inner join marks_entry on student_reg.register_number = marks_entry.register_number where class='" + DropDownList4.SelectedValue + "' and section = '" + DropDownList5.SelectedValue + "' and [group] = '" + RadioButtonList3.SelectedValue + "'", con1);


                        SqlDataAdapter ad_mark = new SqlDataAdapter("Select marks from marks_entry where register_number='" + dt_regno.Rows[i][0].ToString() + "' and activity='" + dt_activity.Rows[j][0].ToString() + "'   ", con1);
                        DataTable dt_mark = new DataTable();
                        ad_mark.Fill(dt_mark);
                        if (dt_mark.Rows.Count > 0)
                        {

                            for (int k = 0; k < dt_mark.Rows.Count; k++)
                            {
                                dr[dt_activity.Rows[j][0].ToString()] = dt_mark.Rows[k][0].ToString();
                                mark = Convert.ToDecimal(dt_mark.Rows[k][0].ToString());
                            }

                        }
                        else
                        {
                            dr[dt_activity.Rows[j][0].ToString()] = "0";
                            mark = 0;
                        }

                        mark1 = mark1 + mark;
                    }


                }

                dr["Total"] = mark1.ToString();
                double average = Convert.ToDouble(mark1) / Convert.ToDouble(dt_activity.Rows.Count);
                dr["Average"] = average.ToString("0.00");
                td.Rows.Add(dr);

            }

        }
        GridView1.Visible = true;
        GridView1.DataSource = td;
        GridView1.DataBind();









    }
    void individial_report_false()
    {
        RadioButtonList2.Visible = false;
        DropDownList1.Visible = false;
        DropDownList2.Visible = false;
        DropDownList3.Visible = false;

        Label1.Visible = false;
        Label2.Visible = false;
        Label3.Visible = false;
        Label4.Visible = false;

        Panel2.Visible = false;
        RadioButtonList5.Visible = false;
        //field1.visible = false;

        GridView1.Visible = false;
    }
    void classwise_report_false()
    {
        Label5.Visible = false;
        Label6.Visible = false;
        Label7.Visible = false;
        DropDownList4.Visible = false;
        DropDownList5.Visible = false;
        RadioButtonList3.Visible = false;
        GridView1.Visible = false;
    }
    void groupwise_false()
    {
        Label8.Visible = false;
        RadioButtonList4.Visible = false;
        GridView1.Visible = false;
    }

    protected void RadioButtonList5_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "Individual Report")
        {
            individual_report_display();
        }
        else if (RadioButtonList1.SelectedValue == "Classwise Report")
        {
            classwise_report_display();
        }
        else if (RadioButtonList1.SelectedValue == "Groupwise Report")
        {
            
        }




    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    
    
    //individual report display for category marks
    void individual_report_display()
    {
        GridView2.Visible = true;
        DataTable td = new DataTable();
        td.Columns.Add("S.No");
        td.Columns.Add("RegNo");
        td.Columns.Add("Group");
        string radio_activity = RadioButtonList5.SelectedValue;
        SqlDataAdapter ad_activity = new SqlDataAdapter("Select distinct category_id,category from rubrics where activity = '" + radio_activity + "' ", con1);
        DataTable dt_activity = new DataTable();
        ad_activity.Fill(dt_activity);
        if (dt_activity.Rows.Count > 0)
        {
            for (int i = 0; i < dt_activity.Rows.Count; i++)
            {
                td.Columns.Add(dt_activity.Rows[i][1].ToString());
            }
        }
        td.Columns.Add("Total");
        td.Columns.Add("Average");
        //td.Columns.Add("Total");
        //DataRow dr = td.NewRow();
        //dr["S.No"] = "1";
        //td.Rows.Add(dr);
        decimal mark = 0, mark1 = 0;
        SqlDataAdapter ad_regno = new SqlDataAdapter("Select distinct register_number,[group] from marks_entry1 where register_number = '" + DropDownList3.SelectedValue + "'", con1);
        //SqlDataAdapter ad_regno = new SqlDataAdapter("Select distinct register_number, [group] from marks_entry1 ", con1);
        DataTable dt_regno = new DataTable();
        ad_regno.Fill(dt_regno);
        if (dt_regno.Rows.Count > 0)
        {

            for (int i = 0; i < dt_regno.Rows.Count; i++)
            {

                //td.Columns.Add(dt_regno.Rows[i][0].ToString());
                DataRow dr = td.NewRow();
                dr["S.No"] = i + 1;
                dr["Regno"] = dt_regno.Rows[i][0].ToString();
                dr["Group"] = dt_regno.Rows[i][1].ToString();
                if (dt_activity.Rows.Count > 0)
                {

                    for (int j = 0; j < dt_activity.Rows.Count; j++)
                    {
                        //dr[dt_activity.Rows[j][0].ToString()] = "1";
                        SqlDataAdapter ad_mark = new SqlDataAdapter("Select marks from marks_entry1 where register_number='" + dt_regno.Rows[i][0].ToString() + "' and category_id='" + dt_activity.Rows[j][0].ToString() + "' and activity='" + radio_activity + "' ", con1);
                        DataTable dt_mark = new DataTable();
                        ad_mark.Fill(dt_mark);
                        if (dt_mark.Rows.Count > 0)
                        {

                            for (int k = 0; k < dt_mark.Rows.Count; k++)
                            {
                                dr[dt_activity.Rows[j][1].ToString()] = dt_mark.Rows[k][0].ToString();
                                mark = Convert.ToDecimal(dt_mark.Rows[k][0].ToString());
                            }

                        }
                        else
                        {
                            dr[dt_activity.Rows[j][1].ToString()] = "0";
                            mark = 0;
                        }

                        mark1 = mark1 + mark;
                    }


                }
                dr["Total"] = mark1.ToString();
                double average = Convert.ToDouble(mark1) / Convert.ToDouble(dt_activity.Rows.Count);
                dr["Average"] = average.ToString("0.00");
                td.Rows.Add(dr);
                mark1 = 0;

                GridView2.DataSource = td;
                GridView2.DataBind();

            }
        }
    }


// classwise report display

    void classwise_report_display()
    {
        GridView2.Visible = true;
        DataTable td = new DataTable();
        td.Columns.Add("S.No");
        td.Columns.Add("RegNo");
        td.Columns.Add("Group");
        td.Columns.Add("Class");
        td.Columns.Add("Section");
        SqlDataAdapter ad_activity = new SqlDataAdapter("Select distinct category_id,category from rubrics where activity = '"+RadioButtonList5.SelectedValue+"' ", con1);
        DataTable dt_activity = new DataTable();
        ad_activity.Fill(dt_activity);
        if (dt_activity.Rows.Count > 0)
        {
            for (int i = 0; i < dt_activity.Rows.Count; i++)
            {
                td.Columns.Add(dt_activity.Rows[i][1].ToString());
            }
        }
        td.Columns.Add("Total");
        td.Columns.Add("Average");
        

        SqlDataAdapter ad_regno = new SqlDataAdapter("Select distinct student_reg.register_number,marks_entry1.[group],student_reg.class,student_reg.section from student_reg inner join marks_entry1 on student_reg.register_number = marks_entry1.register_number  where marks_entry1.[group] = '" + RadioButtonList3.SelectedValue + "' and class = '" + DropDownList4.SelectedValue + "' and section = '" + DropDownList5.SelectedValue + "'", con1);
        DataTable dt_regno = new DataTable();
        ad_regno.Fill(dt_regno);
        if (dt_regno.Rows.Count > 0)
        {

            for (int i = 0; i < dt_regno.Rows.Count; i++)
            {
                decimal mark = 0, mark1 = 0;
                //td.Columns.Add(dt_regno.Rows[i][0].ToString());
                DataRow dr = td.NewRow();
                dr["S.No"] = i + 1;
                dr["Regno"] = dt_regno.Rows[i][0].ToString();
                dr["Group"] = dt_regno.Rows[i][1].ToString();
                dr["class"] = dt_regno.Rows[i][2].ToString();
                dr["Section"] = dt_regno.Rows[i][3].ToString();
                if (dt_activity.Rows.Count > 0)
                {

                    for (int j = 0; j < dt_activity.Rows.Count; j++)
                    {
                        //dr[dt_activity.Rows[j][0].ToString()] = "1";
                        SqlDataAdapter ad_mark = new SqlDataAdapter("Select marks from marks_entry1 where register_number='" + dt_regno.Rows[i][0].ToString() + "' and category_id='" + dt_activity.Rows[j][0].ToString() + "' and activity = '"+ RadioButtonList5.SelectedValue+"'  ", con1);
                        DataTable dt_mark = new DataTable();
                        ad_mark.Fill(dt_mark);
                        if (dt_mark.Rows.Count > 0)
                        {

                            for (int k = 0; k < dt_mark.Rows.Count; k++)
                            {
                                dr[dt_activity.Rows[j][1].ToString()] = dt_mark.Rows[k][0].ToString();
                                mark = Convert.ToDecimal(dt_mark.Rows[k][0].ToString());
                            }

                        }
                        else
                        {
                            dr[dt_activity.Rows[j][1].ToString()] = "0";
                            mark = 0;
                        }

                        mark1 = mark1 + mark;
                    }


                }
                dr["Total"] = mark1.ToString();
                double average = Convert.ToDouble(mark1) / Convert.ToDouble(dt_activity.Rows.Count);

                dr["Average"] = average.ToString("0.00");
                td.Rows.Add(dr);
                mark1 = 0;
            }
        }



        GridView2.DataSource = td;
        GridView2.DataBind();

    }


    void groupwise_report()
    {







    }















}