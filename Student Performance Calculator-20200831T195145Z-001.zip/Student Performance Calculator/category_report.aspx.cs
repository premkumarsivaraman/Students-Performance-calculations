﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=school_project; integrated Security=true;");      
    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable td = new DataTable();
        td.Columns.Add("S.No");
        td.Columns.Add("RegNo");
        td.Columns.Add("Group");
        SqlDataAdapter ad_activity = new SqlDataAdapter("Select distinct category_id,category from rubrics where activity = 'creativity' ", con);
        DataTable dt_activity = new DataTable();
        ad_activity.Fill(dt_activity);
        if (dt_activity.Rows.Count > 0)
        {
            for (int i = 0; i < dt_activity.Rows.Count; i++)
            {
                td.Columns.Add(dt_activity.Rows[i][1].ToString());
            }
        }
        td.Columns.Add("Total");
        //td.Columns.Add("Total");
        //DataRow dr = td.NewRow();
        //dr["S.No"] = "1";
        //td.Rows.Add(dr);

        SqlDataAdapter ad_regno = new SqlDataAdapter("Select distinct register_number,[group] from marks_entry1", con);
        DataTable dt_regno = new DataTable();
        ad_regno.Fill(dt_regno);
        if (dt_regno.Rows.Count > 0)
        {

            for (int i = 0; i < dt_regno.Rows.Count; i++)
            {
                decimal mark = 0, mark1 = 0;
                //td.Columns.Add(dt_regno.Rows[i][0].ToString());
                DataRow dr = td.NewRow();
                dr["S.No"] = i + 1;
                dr["Regno"] = dt_regno.Rows[i][0].ToString();
                dr["Group"] = dt_regno.Rows[i][1].ToString();
                if (dt_activity.Rows.Count > 0)
                {

                    for (int j = 0; j < dt_activity.Rows.Count; j++)
                    {
                        //dr[dt_activity.Rows[j][0].ToString()] = "1";
                        SqlDataAdapter ad_mark = new SqlDataAdapter("Select marks from marks_entry1 where register_number='" + dt_regno.Rows[i][0].ToString() + "' and category_id='" + dt_activity.Rows[j][0].ToString() + "'  ", con);
                        DataTable dt_mark = new DataTable();
                        ad_mark.Fill(dt_mark);
                        if (dt_mark.Rows.Count > 0)
                        {

                            for (int k = 0; k < dt_mark.Rows.Count; k++)
                            {
                                dr[dt_activity.Rows[j][1].ToString()] = dt_mark.Rows[k][0].ToString();
                                mark = Convert.ToDecimal(dt_mark.Rows[k][0].ToString());
                            }

                        }
                        else
                        {
                            dr[dt_activity.Rows[j][1].ToString()] = "0";
                            mark = 0;
                        }

                        mark1 = mark1 + mark;
                    }


                }
                dr["Total"] = mark1.ToString();
                td.Rows.Add(dr);
            }
        }








        GridView1.DataSource = td;
            GridView1.DataBind();
    }
}