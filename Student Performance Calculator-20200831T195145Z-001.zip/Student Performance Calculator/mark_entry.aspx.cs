﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{

    SqlConnection con1 = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=school_project; integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {
         //Label8.Text = Session["user"].ToString();

        if (!IsPostBack)
        {
            Label3.Visible = false;
            DropDownList1.Visible = false;

            Label4.Visible = false;
            DropDownList2.Visible = false;

            Label5.Visible = false;
            DropDownList3.Visible = false;

            Label6.Visible = false;
            DropDownList4.Visible = false;

            Label7.Visible = false;
            Button1.Visible = false;


            GridView1.Columns[0].Visible = true;
            

           
        }
    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        string s = "select sid from student_reg where register_number='"+DropDownList1.Text+"'";
        SqlCommand cmd = new SqlCommand(s,con1);
        con1.Open();
        cmd.ExecuteNonQuery();
        con1.Close();

        int t = 0;
        int mid;

      

        SqlDataAdapter ad = new SqlDataAdapter("select max(mid) from marks_entry1", con1);
        DataTable dt = new DataTable();
        ad.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0][0].ToString() == "")
            {
                mid = 101;
            }
            else
            {
                mid = Convert.ToInt32(dt.Rows[0][0].ToString()) + 1;

            }

            int activity_total = 0;
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                string category_id = GridView1.Rows[i].Cells[0].Text;
                TextBox TextBox1 = (TextBox)GridView1.Rows[i].Cells[2].FindControl("TextBox1");
                int tb = Convert.ToInt32(TextBox1.Text);
                activity_total = activity_total + tb;

                SqlCommand cmd1 = new SqlCommand("insert into marks_entry1 (mid,register_number,[group],activity,marks,category_id) values ('" + mid + "','" + DropDownList3.Text + "','" + chkLstFavColor.Text + "','" + DropDownList4.Text + "','" + tb + "','" + category_id + "')", con1);
                con1.Open();
                cmd1.ExecuteNonQuery();
                con1.Close();

            }


            SqlCommand activity_cmd = new SqlCommand("insert into marks_entry (mid,register_number,[group],activity,marks) values ('" + mid + "','" + DropDownList3.Text + "','" + chkLstFavColor.Text + "','" + DropDownList4.Text + "','" + activity_total + "')", con1);
            con1.Open();
            activity_cmd.ExecuteNonQuery();
            con1.Close();

            activity_total = 0;


            string div = "select COUNT(category) from rubrics where activity = '" + DropDownList4.SelectedValue + "' ";
            SqlCommand cmd4 = new SqlCommand(div, con1);
            con1.Open();
            //int divide = Convert.ToInt32(cmd4.ExecuteScalar().ToString());
            con1.Close();

            //divide = divide * 100;
            //t = t / divide;



            //SqlCommand cmd1 = new SqlCommand("insert into marks_entry1 (mid,register_number,[group],activity,marks) values ('" + mid + "','" + DropDownList3.Text + "','" + chkLstFavColor.Text + "','" + DropDownList4.Text + "','" + t + "')", con1);
            //con1.Open();
            //cmd1.ExecuteNonQuery();
            //con1.Close();

            Button1.Visible = false;
            GridView1.Visible = false;
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlDataAdapter ad = new SqlDataAdapter("select distinct class from student_reg", con1);
        DataTable dt = new DataTable();
        ad.Fill(dt);

        DropDownList1.Items.Clear();
        DropDownList2.Items.Clear();
        DropDownList3.Items.Clear();
        DropDownList4.Items.Clear();
        GridView1.Visible = false;
        if (dt.Rows.Count > 0)
        {

            DropDownList1.DataSource = dt;
            DropDownList1.DataBind();
            DropDownList1.DataTextField = "class";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0,new ListItem("Select",""));
            Label3.Visible = true;
            DropDownList1.Visible = true;
        }
        else
        {

        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlDataAdapter ad1 = new SqlDataAdapter("select distinct section from student_reg where class='" + DropDownList1.Text + "'", con1);
        DataTable dt1= new DataTable();
        ad1.Fill(dt1);

        DropDownList2.Items.Clear();
        DropDownList3.Items.Clear();
        DropDownList4.Items.Clear();
        GridView1.Visible = false;
        Button1.Visible = false;

        DropDownList2.DataSource = dt1;
        DropDownList2.DataBind();
        DropDownList2.DataTextField = "section";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("Select", ""));

        Label4.Visible = true;
        DropDownList2.Visible = true;
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlDataAdapter ad1 = new SqlDataAdapter("select register_number from student_reg where class='"+DropDownList1.SelectedValue+"' and  section='" + DropDownList2.Text + "'", con1);
        DataTable dt1 = new DataTable();
        ad1.Fill(dt1);

        DropDownList3.Items.Clear();
        GridView1.Visible = false;
        Button1.Visible = false;

        DropDownList3.DataSource = dt1;
        DropDownList3.DataBind();
        DropDownList3.DataTextField = "register_number";
        DropDownList3.DataBind();
        DropDownList3.Items.Insert(0, new ListItem("Select", ""));


        Label5.Visible = true;
        DropDownList3.Visible = true;

    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlDataAdapter ad1 = new SqlDataAdapter("select distinct activity from rubrics", con1);
        DataTable dt1 = new DataTable();
        ad1.Fill(dt1);

        DropDownList4.Items.Clear();
        GridView1.Visible = false;
        Button1.Visible = false;

        DropDownList4.DataSource = dt1;
        DropDownList4.DataBind();
        DropDownList4.DataTextField = "activity";
        DropDownList4.DataBind();
        DropDownList4.Items.Insert(0, new ListItem("Select", ""));


        Label6.Visible = true;
        DropDownList4.Visible = true;
    }
    
    protected void DropDownList4_SelectedIndexChanged1(object sender, EventArgs e)
    {
        GridView1.Visible = true;
        Label7.Visible = true;

        DataTable td = new DataTable();
        td.Columns.Add("Id");
        td.Columns.Add("Category");
        td.Columns.Add("Value");

        SqlDataAdapter ad = new SqlDataAdapter("Select distinct category_id,category from rubrics where activity ='" + DropDownList4.SelectedValue + "'", con1);
        DataTable dt = new DataTable();
        ad.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = td.NewRow();
                dr["Id"] = dt.Rows[i][0].ToString();
                dr["Category"] = dt.Rows[i][1].ToString();
                dr["Value"] = "";
                td.Rows.Add(dr);
            }
            GridView1.DataSource = td;
            GridView1.DataBind();
            
            Button1.Visible = true;

        }
    }
}