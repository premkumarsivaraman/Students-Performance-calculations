﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class login_form : System.Web.UI.Page
{

    SqlConnection con1 = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=school_project; integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("staff_registration.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

            
            SqlDataAdapter ad1 = new SqlDataAdapter("select email_id,password,access from staff_registration where email_id='"+TextBox1.Text+"' and password='"+TextBox2.Text+"' and access='1'", con1);
            DataTable dt1 = new DataTable();
            ad1.Fill(dt1);

            if (dt1.Rows.Count > 0)
            {
                Session["user"] = TextBox1.Text;
                Response.Redirect("mark_entry.aspx");
            }

            else
            {
            Page.RegisterStartupScript("msg", "<script>alert('email or password is worng else your permission not given by ADMIN');</script>");
            }
            
        }




    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("student_registration.aspx");
    }
}