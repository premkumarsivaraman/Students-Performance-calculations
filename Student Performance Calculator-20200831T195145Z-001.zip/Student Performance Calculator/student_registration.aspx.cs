﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class student_regsitration : System.Web.UI.Page
{

    SqlConnection con1 = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=school_project; integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int sid;
        SqlDataAdapter ad = new SqlDataAdapter("select max(sid) from student_reg", con1);
        DataTable dt = new DataTable();
        ad.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0][0].ToString() == "")
            {
                sid = 1001;
            }
            else
            {
                sid = Convert.ToInt32(dt.Rows[0][0].ToString()) + 1;

            }
            
                SqlCommand cmd = new SqlCommand("insert into student_reg (sid,name,register_number,class,section,sex,age,phone_no) values ('" + sid + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + DropDownList1.Text + "','" + DropDownList2.Text + "','" + RadioButtonList1.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')", con1);
                con1.Open();
                cmd.ExecuteNonQuery();
                con1.Close();
                
                SqlCommand cmd1 = new SqlCommand("insert into activity_wise (register_number) values ('"+TextBox2.Text+"') ",con1);
                con1.Open();
                cmd1.ExecuteNonQuery();
                con1.Close();

                Page.RegisterStartupScript("msg", "<script>alert('Details Registered')</script>");
                TextBox1.Text = "";
                TextBox2.Text = "";
                DropDownList1.Text = "__select__";
                DropDownList2.Text = "__select__";
                TextBox4.Text = "";
                TextBox5.Text = "";
                RadioButtonList1.SelectedValue = null;

        
            }
        }
  
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        DropDownList1.Text = "";
        DropDownList2.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        RadioButtonList1.Text = "";
        Response.Redirect("login_form.aspx");

    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {
        

    }
}