﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Session.Remove("user");
        Session.RemoveAll();
        Response.Redirect("login_form.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("report_generation.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("mark_entry.aspx");
    }
}
