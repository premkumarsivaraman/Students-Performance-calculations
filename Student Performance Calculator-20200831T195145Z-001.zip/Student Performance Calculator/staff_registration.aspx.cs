﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class staff_registration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=school_project; integrated Security=true;");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string tb5 = TextBox5.Text;
        string tb6 = TextBox6.Text;
        if (tb5.Equals(tb6))
        {
            int a = 0;
            SqlCommand cmd = new SqlCommand("insert into staff_registration(email_id,name,phone_number,designation,password,access) values ('" + TextBox4.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + tb5 + "','"+a+"')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Page.RegisterStartupScript("msg", "<script>alert('Registration Completed Further Access Given by ADMIN');</script>");
        }
        else
        {
            Page.RegisterStartupScript("msg","<script>alert('Password Does Not Match');</script>");
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        tb5 = "";
        tb6 = "";
        Response.Redirect("login_form.aspx");

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("login_form.aspx");
    }
}